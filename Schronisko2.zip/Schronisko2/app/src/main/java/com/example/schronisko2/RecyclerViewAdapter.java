package com.example.schronisko2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    Context context;
    RecyclerView recyclerView;
    ArrayList<AnimalObject> animalObjects;

    RecyclerViewAdapter(Context context, ArrayList<AnimalObject> animalObjects, RecyclerView recyclerView){
        this.context = context;
        this.animalObjects = animalObjects;
        this.recyclerView = recyclerView;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView tvName, tvAge, tvSex, tvDescription;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.iv_Image);
            tvName = itemView.findViewById(R.id.tv_Name);
            tvAge = itemView.findViewById(R.id.tv_Age);
            tvSex = itemView.findViewById(R.id.tv_Sex);
            tvDescription = itemView.findViewById(R.id.tv_Description);

        }
    }



    @NonNull
    @Override
    public RecyclerViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.animal_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.ViewHolder holder, int position) {
        holder.itemView.setTag(animalObjects.get(position));
        holder.tvName.setText(animalObjects.get(position).getName());
        holder.tvAge.setText(animalObjects.get(position).getAge());
        holder.tvSex.setText(animalObjects.get(position).getSex());
        holder.tvDescription.setText(animalObjects.get(position).getDescription());

        if(animalObjects.get(position).getPhoto_path().equals("cat")){
            holder.imageView.setImageResource(R.drawable.cat);
        }
        else if(animalObjects.get(position).getPhoto_path().equals("pies")){
            holder.imageView.setImageResource(R.drawable.pies);
        }else{
            holder.imageView.setImageResource(R.drawable.pies);
        }
    }

    @Override
    public int getItemCount() {
        return animalObjects.size();
    }
}
