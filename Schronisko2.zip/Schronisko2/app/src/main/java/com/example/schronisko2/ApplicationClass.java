package com.example.schronisko2;

import android.app.Application;

import java.util.ArrayList;

public class ApplicationClass extends Application {

    public static ArrayList<AnimalObject> animals;

    @Override
    public void onCreate() {
        super.onCreate();

        animals = new ArrayList<AnimalObject>();
        animals.add(new AnimalObject(0, "Czarek", "4 lata", "cat", "samica", "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum "));
        animals.add(new AnimalObject(1, "Czarek", "4 lata", "pies", "samica", "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum "));
        animals.add(new AnimalObject(2, "Czarek", "4 lata", "pies2", "samica", "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum "));
        animals.add(new AnimalObject(3, "Czarek", "4 lata", "cat", "samica", "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum "));
    }
}
